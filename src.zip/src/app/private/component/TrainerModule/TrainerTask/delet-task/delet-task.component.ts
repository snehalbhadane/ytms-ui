import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delet-task',
  templateUrl: './delet-task.component.html',
  styleUrls: ['./delet-task.component.css']
})
export class DeletTaskComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
