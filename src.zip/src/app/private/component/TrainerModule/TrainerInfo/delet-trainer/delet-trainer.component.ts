import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delet-trainer',
  templateUrl: './delet-trainer.component.html',
  styleUrls: ['./delet-trainer.component.css']
})
export class DeletTrainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
