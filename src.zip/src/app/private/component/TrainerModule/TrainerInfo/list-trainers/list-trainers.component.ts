import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-trainers',
  templateUrl: './list-trainers.component.html',
  styleUrls: ['./list-trainers.component.css']
})
export class ListTrainersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
