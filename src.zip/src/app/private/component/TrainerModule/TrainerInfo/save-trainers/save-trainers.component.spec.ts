import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaveTrainersComponent } from './save-trainers.component';

describe('SaveTrainersComponent', () => {
  let component: SaveTrainersComponent;
  let fixture: ComponentFixture<SaveTrainersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SaveTrainersComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SaveTrainersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
