import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Trainer } from 'src/app/public/Entity/trainer';
import { TrainerprofileService } from 'src/app/public/service/trainerprofile.service';

@Component({
  selector: 'app-save-trainers',
  templateUrl: './save-trainers.component.html',
  styleUrls: ['./save-trainers.component.css']
})
export class SaveTrainersComponent implements OnInit {

  trainer:Trainer=new Trainer();

  constructor(private trainserprofileService:TrainerprofileService, private router:Router) { }

  ngOnInit(): void {
  }
saveTrainer(){
  this.trainserprofileService.addTrainer(this.trainer).subscribe(data=>{
    console.log(data)
    window.location.reload();
  })
}
  onSubmit(){
    console.log(this.trainer)
    this.saveTrainer();
  }
}
