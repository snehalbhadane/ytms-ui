import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-trainer',
  templateUrl: './update-trainer.component.html',
  styleUrls: ['./update-trainer.component.css']
})
export class UpdateTrainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
