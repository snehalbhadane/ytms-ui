export class TrainerTask {

    trainerTaskId !: number;
    taskDate !:Date;
    firstHalf! :String;
    firstHalfDescription !: String;
    secondHalf !:String;
    secondHalfDescription !:String;
    createdBy !:any;
    trainer !:any;
    createdOn !:Date;
    updatedOn !: Date;
    




}


