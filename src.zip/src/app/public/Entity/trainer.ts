export class Trainer {

    trainerId !: number;
    user !:any;
    currentLocation !:String;
    baseLocation !:String;
    irm!:String;
    type! : String;
    totalExperience !:String;
    createdOn !: Date;
    updatedOn! :Date;


}
