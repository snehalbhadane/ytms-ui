import { TrainerTask } from './trainer-task';

describe('TrainerTask', () => {
  it('should create an instance', () => {
    expect(new TrainerTask()).toBeTruthy();
  });
});
